package com.org;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

//*Test case:
//1.	Go to https://www.webstaurantstore.com/
//2.	Search for 'stainless work table'.
//3.	Check the search result ensuring every product has the word 'Table' in its title.
//4.	Add the last of found items to Cart.
//5.	Empty Cart.

public class StainlessWorkTables {

	public static void main(String[] args) throws InterruptedException {
		
System.setProperty("webdriver.chrome.driver", ".//drivers//chromedriver.exe");
ChromeDriver driver=new ChromeDriver();
driver.get("https://www.webstaurantstore.com/");
driver.manage().window().maximize();
driver.findElement(By.xpath("//input[@id='searchval']")).sendKeys("stainless work table",Keys.ENTER);
	Thread.sleep(4000);
	List<WebElement> allTables = driver.findElements(By.xpath("//a[text()[contains(.,'Table with')]]"));
	System.out.println("Total Tables in Page"+allTables.size());
	allTables.get(allTables.size()-1).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//input[@value='Add to Cart']")).click();
	Thread.sleep(4000);
	driver.findElement(By.xpath("//button[text()='Orders']/following::span/..")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//button[text()='Empty Cart']")).click();
	driver.findElement(By.xpath("//p[text()[contains(.,'Are you sure you want to empty your')]]/following::button")).click();
	
	
	}

}
